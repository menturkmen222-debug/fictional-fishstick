# Git Setup Instructions for AI Video Factory

Since git operations are restricted in the Replit environment, follow these steps to create your GitHub repository and set up version control.

## 📋 Prerequisites

- GitHub account
- Git installed locally
- GitHub CLI (optional, recommended)

## 🚀 Option 1: Using GitHub CLI (Recommended)

```bash
# Install GitHub CLI if not already installed
# macOS: brew install gh
# Windows: winget install GitHub.cli
# Linux: https://github.com/cli/cli/blob/trunk/docs/install_linux.md

# Login to GitHub
gh auth login

# Create the repository
gh repo create ai-video-factory --public --description "AI-powered video generation pipeline with web UI, backend API, and worker tasks"

# Initialize and push
git init
git add .
git commit -m "chore: initial project scaffold"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/ai-video-factory.git
git push -u origin main

# Create dev branch
git checkout -b dev
git push -u origin dev

# Make additional commits
git add backend frontend worker
git commit -m "feat: implement backend API and job queue"
git push origin dev

git add .github infra tests
git commit -m "feat: implement worker and CI/CD"
git push origin dev

# Create PR
gh pr create --title "feat: scaffold project" --body "Initial project scaffolding with:
- React + TypeScript frontend
- Express + TypeScript backend API
- Python AI worker
- Cloudflare deployment infrastructure
- CI/CD pipelines
- Comprehensive documentation
" --base main --head dev
```

## 🛠️ Option 2: Using Git Commands Only

```bash
# 1. Create repository on GitHub
# Go to https://github.com/new
# Repository name: ai-video-factory
# Description: AI-powered video generation pipeline
# Visibility: Public
# Don't initialize with README, .gitignore, or license

# 2. Initialize and push from Replit
git init
git add .
git commit -m "chore: initial project scaffold"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/ai-video-factory.git
git push -u origin main

# 3. Create dev branch
git checkout -b dev

# 4. Make additional commits
git add backend frontend worker
git commit -m "feat: implement backend API and job queue"

git add .github infra tests
git commit -m "feat: implement worker and CI/CD"

git push -u origin dev
git push origin main

# 5. Create Pull Request
# Go to https://github.com/YOUR_USERNAME/ai-video-factory
# Click "Pull requests" → "New pull request"
# Base: main ← Compare: dev
# Title: "feat: scaffold project"
# Description: "Initial project scaffolding with all components"
```

## 📝 Commit History Structure

Your repository should have the following commit history:

### Main Branch:
1. `chore: initial project scaffold` - Base structure and configuration

### Dev Branch (3 commits):
1. `chore: initial project scaffold` - Base structure
2. `feat: implement backend API and job queue` - Backend implementation
3. `feat: implement worker and CI/CD` - Worker and deployment configs

## 🔐 Setting Up GitHub Secrets

After creating the repository, add the required secrets:

1. Go to your repository on GitHub
2. Navigate to **Settings** → **Secrets and variables** → **Actions**
3. Click **New repository secret** for each of these:

| Secret Name | Description | How to Get |
|------------|-------------|------------|
| `CLOUDFLARE_API_TOKEN` | API token with Workers and Pages permissions | 1. Go to https://dash.cloudflare.com/profile/api-tokens<br>2. Create Token → Edit Cloudflare Workers<br>3. Add "Account:Cloudflare Pages:Edit" permission |
| `CLOUDFLARE_ACCOUNT_ID` | Your Cloudflare account ID | 1. Go to https://dash.cloudflare.com/<br>2. Copy the Account ID from the right sidebar |
| `CF_PAGES_PROJECT` | Your Pages project name | Choose a name like `ai-video-factory` |
| `CLOUDFLARE_ZONE_ID` | (Optional) For custom domains | 1. Go to https://dash.cloudflare.com/<br>2. Select your domain<br>3. Copy Zone ID from right sidebar |

## 🎯 Verifying Setup

After pushing to GitHub:

1. **Check Actions tab** to see if CI workflow runs
2. **Verify branches** - you should have `main` and `dev`
3. **Check Pull Request** - dev → main should be created
4. **Test deployment** - Merge the PR to trigger Cloudflare deployment

## 🔄 Future Workflow

For future changes:

```bash
# Create feature branch
git checkout dev
git pull origin dev
git checkout -b feature/your-feature

# Make changes and commit
git add .
git commit -m "feat: your feature description"
git push origin feature/your-feature

# Create PR on GitHub: feature/your-feature → dev
# After review and merge, create PR: dev → main
```

## 📚 Additional Resources

- [Git Documentation](https://git-scm.com/doc)
- [GitHub CLI Documentation](https://cli.github.com/manual/)
- [GitHub Actions Documentation](https://docs.github.com/en/actions)
- [Cloudflare Workers Documentation](https://developers.cloudflare.com/workers/)
- [Cloudflare Pages Documentation](https://developers.cloudflare.com/pages/)

## 🆘 Troubleshooting

### Can't push to repository
```bash
# Check remote URL
git remote -v

# Update if needed
git remote set-url origin https://github.com/YOUR_USERNAME/ai-video-factory.git
```

### Authentication issues
```bash
# Use GitHub CLI
gh auth login

# Or use personal access token
# Settings → Developer settings → Personal access tokens
# Create token with repo scope
```

### Merge conflicts
```bash
# Pull latest changes
git pull origin dev

# Resolve conflicts in your editor
# Then commit
git add .
git commit -m "fix: resolve merge conflicts"
git push
```

---

**Note**: Replace `YOUR_USERNAME` with your actual GitHub username in all commands above.
