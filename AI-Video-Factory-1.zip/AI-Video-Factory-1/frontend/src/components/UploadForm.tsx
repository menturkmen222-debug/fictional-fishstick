import { useState, FormEvent } from 'react';

interface UploadFormProps {
  onSubmit: (data: VideoRequest) => void;
  isLoading: boolean;
}

export interface VideoRequest {
  prompt: string;
  voice: string;
  style: string;
  length: number;
}

export function UploadForm({ onSubmit, isLoading }: UploadFormProps) {
  const [prompt, setPrompt] = useState('');
  const [voice, setVoice] = useState('neutral');
  const [style, setStyle] = useState('cinematic');
  const [length, setLength] = useState(30);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) {
      alert('Please enter a video prompt');
      return;
    }
    onSubmit({ prompt, voice, style, length });
  };

  return (
    <form onSubmit={handleSubmit} className="form-container">
      <div className="form-group">
        <label htmlFor="prompt">Video Prompt:</label>
        <textarea
          id="prompt"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Describe your video... (e.g., 'A serene mountain landscape at sunset')"
          rows={4}
          required
          disabled={isLoading}
          data-testid="input-prompt"
        />
      </div>

      <div className="form-row">
        <div className="form-group">
          <label htmlFor="voice">Voice:</label>
          <select
            id="voice"
            value={voice}
            onChange={(e) => setVoice(e.target.value)}
            disabled={isLoading}
            data-testid="select-voice"
          >
            <option value="neutral">Neutral</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="child">Child</option>
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="style">Style:</label>
          <select
            id="style"
            value={style}
            onChange={(e) => setStyle(e.target.value)}
            disabled={isLoading}
            data-testid="select-style"
          >
            <option value="cinematic">Cinematic</option>
            <option value="anime">Anime</option>
            <option value="realistic">Realistic</option>
            <option value="cartoon">Cartoon</option>
            <option value="abstract">Abstract</option>
          </select>
        </div>
      </div>

      <div className="form-group">
        <label htmlFor="length">Length: {length} seconds</label>
        <input
          type="range"
          id="length"
          min="5"
          max="60"
          value={length}
          onChange={(e) => setLength(parseInt(e.target.value))}
          disabled={isLoading}
          data-testid="input-length"
        />
      </div>

      <button 
        type="submit" 
        disabled={isLoading} 
        className="submit-button"
        data-testid="button-submit"
      >
        {isLoading ? 'Creating...' : 'Generate Video'}
      </button>
    </form>
  );
}
