import { useEffect, useState } from 'react';
import { formatDate } from '../utils/time';

interface VideoPlayerProps {
  jobId: string;
  apiUrl: string;
}

interface JobStatus {
  jobId: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  createdAt: number;
  updatedAt: number;
  outputUrl?: string;
  error?: string;
  progress: number;
}

export function VideoPlayer({ jobId, apiUrl }: VideoPlayerProps) {
  const [status, setStatus] = useState<JobStatus | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let intervalId: number;

    const checkStatus = async () => {
      try {
        const response = await fetch(`${apiUrl}/api/status/${jobId}`);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        setStatus(data);

        if (data.status === 'completed' || data.status === 'failed') {
          clearInterval(intervalId);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch status');
        clearInterval(intervalId);
      }
    };

    checkStatus();
    intervalId = window.setInterval(checkStatus, 2000);

    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [jobId, apiUrl]);

  if (error) {
    return (
      <div className="status-card error" data-testid="status-error">
        <h3>Error</h3>
        <p>{error}</p>
      </div>
    );
  }

  if (!status) {
    return (
      <div className="status-card" data-testid="status-loading">
        <h3>Loading...</h3>
      </div>
    );
  }

  return (
    <div className="status-card" data-testid={`status-${status.status}`}>
      <h3>Job Status</h3>
      <div className="status-info">
        <p><strong>Job ID:</strong> <span data-testid="text-jobid">{status.jobId}</span></p>
        <p><strong>Status:</strong> <span data-testid="text-status">{status.status}</span></p>
        <p><strong>Progress:</strong> <span data-testid="text-progress">{status.progress}%</span></p>
        <p><strong>Created:</strong> {formatDate(status.createdAt)}</p>
        <p><strong>Updated:</strong> {formatDate(status.updatedAt)}</p>
      </div>

      {status.status === 'pending' && (
        <div className="status-message">
          <p>⏳ Your video is in the queue...</p>
        </div>
      )}

      {status.status === 'processing' && (
        <div className="status-message">
          <p>🎬 Generating your video...</p>
        </div>
      )}

      {status.status === 'completed' && status.outputUrl && (
        <div className="video-result">
          <p className="success-message" data-testid="text-success">✅ Video ready!</p>
          <video 
            controls 
            className="video-player" 
            src={`${apiUrl}${status.outputUrl}`}
            data-testid="video-player"
          >
            Your browser does not support the video tag.
          </video>
          <a 
            href={`${apiUrl}${status.outputUrl}`} 
            download 
            className="download-link"
            data-testid="link-download"
          >
            Download Video
          </a>
        </div>
      )}

      {status.status === 'failed' && (
        <div className="status-message error" data-testid="text-error">
          <p>❌ Video generation failed</p>
          {status.error && <p className="error-detail">{status.error}</p>}
        </div>
      )}
    </div>
  );
}
