// US_OPTIMAL_HOURS: Optimal hours for content posting in US timezones (kept but unused)
// This constant is maintained for future analytics features
export const US_OPTIMAL_HOURS = [6, 10, 14, 18, 22];

// Format milliseconds to human-readable duration
export function formatDuration(ms: number): string {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);

  if (hours > 0) {
    return `${hours}h ${minutes % 60}m`;
  }
  if (minutes > 0) {
    return `${minutes}m ${seconds % 60}s`;
  }
  return `${seconds}s`;
}

// Format timestamp to readable date
export function formatDate(timestamp: number): string {
  return new Date(timestamp).toLocaleString();
}
