import { useState } from 'react';
import { UploadForm, VideoRequest } from './components/UploadForm';
import { VideoPlayer } from './components/VideoPlayer';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001';

function App() {
  const [jobId, setJobId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (data: VideoRequest) => {
    setIsLoading(true);
    setError(null);
    setJobId(null);

    try {
      const response = await fetch(`${API_URL}/api/create-video`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      setJobId(result.jobId);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create video job');
      console.error('Error creating video:', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="app">
      <header className="app-header">
        <h1>🎬 AI Video Factory</h1>
        <p>Generate AI-powered videos from text prompts</p>
      </header>

      <main className="app-main">
        <section className="form-section">
          <h2>Create New Video</h2>
          <UploadForm onSubmit={handleSubmit} isLoading={isLoading} />
          
          {error && (
            <div className="error-message" data-testid="text-error">
              <p>❌ {error}</p>
            </div>
          )}
        </section>

        {jobId && (
          <section className="status-section">
            <h2>Video Generation Status</h2>
            <VideoPlayer jobId={jobId} apiUrl={API_URL} />
          </section>
        )}
      </main>

      <footer className="app-footer">
        <p>Powered by AI • Built with React + Express</p>
      </footer>
    </div>
  );
}

export default App;
