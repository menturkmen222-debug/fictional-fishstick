# AI Video Factory

## Overview

AI Video Factory is an AI-powered video generation pipeline that allows users to create videos from text prompts. The system consists of a React frontend for user interaction, an Express backend API for job management, and a Python worker for AI processing tasks. Users submit video prompts through the web interface, the backend creates and tracks jobs, and the worker processes them using AI services (Runway ML, ElevenLabs, FFmpeg).

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for both development and production builds
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with custom theme variables
- **State Management**: TanStack React Query for server state
- **Routing**: Wouter for client-side routing
- **Location**: Main client code in `client/src/`, secondary frontend in `frontend/`

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Pattern**: REST API with job queue pattern
- **Job Management**: In-memory job queue with UUID-based job tracking
- **Storage**: Local file storage for video outputs with abstracted storage service
- **API Endpoints**: 
  - `POST /api/create-video` - Creates video generation jobs
  - `GET /api/status/:jobId` - Polls job status
  - `GET /api/videos/:filename` - Serves generated video files

### Data Storage
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Location**: `shared/schema.ts` defines database tables
- **Migrations**: Managed via `drizzle-kit push`
- **Current Tables**: Users table with id, username, password fields
- **Job Storage**: Currently in-memory Map (not persisted to database)

### Worker Architecture
- **Language**: Python 3
- **Pattern**: Polling-based background worker
- **Purpose**: Processes pending video generation jobs
- **AI Integration Points**: Runway ML, ElevenLabs, FFmpeg (placeholder implementations)
- **Communication**: HTTP polling to backend API

### Build System
- **Client Build**: Vite outputs to `dist/public`
- **Server Build**: esbuild bundles to `dist/index.cjs`
- **Monorepo Structure**: Single package.json at root manages both client and server

## External Dependencies

### AI Services (Placeholder)
- **Runway ML**: Video generation from text prompts
- **ElevenLabs**: Voice synthesis for video narration
- **FFmpeg**: Video compositing and effects

### Cloud Infrastructure
- **Cloudflare Pages**: Frontend hosting
- **Cloudflare Workers**: Backend deployment option
- **GitHub Actions**: CI/CD pipeline for deployments

### Database
- **PostgreSQL**: Primary database (requires DATABASE_URL environment variable)
- **Drizzle ORM**: Type-safe database queries and schema management

### Key NPM Packages
- **@tanstack/react-query**: Server state management
- **drizzle-orm**: Database ORM
- **express**: HTTP server framework
- **zod**: Schema validation
- **uuid**: Job ID generation