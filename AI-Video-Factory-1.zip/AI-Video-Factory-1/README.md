# 🎬 AI Video Factory

An AI-powered video generation pipeline with a modern web interface, REST API backend, Python worker for AI processing, and cloud deployment infrastructure.

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        AI Video Factory                          │
└─────────────────────────────────────────────────────────────────┘

┌──────────────┐      ┌──────────────┐      ┌──────────────┐
│   Frontend   │─────▶│   Backend    │─────▶│    Worker    │
│  (React/TS)  │      │  (Express)   │      │   (Python)   │
│              │      │              │      │              │
│  Port: 5000  │◀─────│  Port: 3001  │◀─────│  Background  │
└──────────────┘      └──────────────┘      └──────────────┘
       │                     │                      │
       │                     │                      │
       ▼                     ▼                      ▼
┌──────────────┐      ┌──────────────┐      ┌──────────────┐
│  Cloudflare  │      │  Cloudflare  │      │   AI SDKs    │
│    Pages     │      │   Workers    │      │ • Runway ML  │
│              │      │              │      │ • ElevenLabs │
└──────────────┘      └──────────────┘      │ • FFmpeg     │
                                            └──────────────┘

Flow:
1. User submits video prompt via web UI
2. Frontend sends request to Backend API
3. Backend creates job and returns job ID
4. Worker polls for pending jobs
5. Worker generates video using AI helpers
6. Worker uploads result to storage
7. Frontend polls job status and displays video
```

## 📁 Project Structure

```
ai-video-factory/
├── frontend/              # React + TypeScript web app
│   ├── src/
│   │   ├── components/   # UI components
│   │   ├── utils/        # Utility functions
│   │   ├── App.tsx       # Main app component
│   │   └── main.tsx      # Entry point
│   ├── package.json
│   └── vite.config.ts
│
├── backend/              # Express + TypeScript API
│   ├── src/
│   │   ├── routes/       # API endpoints
│   │   ├── services/     # Business logic
│   │   └── index.ts      # Server entry point
│   ├── package.json
│   └── tsconfig.json
│
├── worker/               # Python AI worker
│   ├── utils/
│   │   └── ai_helper.py  # AI generation helpers
│   ├── worker.py         # Main worker loop
│   └── requirements.txt
│
├── infra/                # Infrastructure configs
│   └── cloudflare/
│       ├── pages/        # Cloudflare Pages config
│       └── worker/       # Cloudflare Workers config
│           └── wrangler.toml
│
├── scripts/              # Deployment scripts
│   ├── setup_env.sh      # Environment setup
│   └── deploy_local.sh   # Local deployment
│
├── tests/                # Test suites
│   ├── backend.test.ts
│   └── frontend.test.ts
│
└── .github/
    └── workflows/        # CI/CD pipelines
        ├── ci.yml
        └── deploy-cloudflare.yml
```

## 🚀 Quick Start

### Prerequisites

- Node.js 20+
- Python 3.9+
- npm or yarn

### Local Development Setup

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/ai-video-factory.git
   cd ai-video-factory
   ```

2. **Run setup script**
   ```bash
   chmod +x scripts/setup_env.sh
   ./scripts/setup_env.sh
   ```

3. **Configure environment variables**
   
   Backend (backend/.env):
   ```env
   BACKEND_PORT=3001
   NODE_ENV=development
   CORS_ORIGIN=http://localhost:5000
   STORAGE_PATH=./uploads
   ```

   Frontend (frontend/.env):
   ```env
   VITE_API_URL=http://localhost:3001
   ```

4. **Start all services**
   ```bash
   # Option 1: Use the deployment script
   chmod +x scripts/deploy_local.sh
   ./scripts/deploy_local.sh

   # Option 2: Start services individually
   # Terminal 1 - Backend
   cd backend && npm run dev

   # Terminal 2 - Frontend
   cd frontend && npm run dev

   # Terminal 3 - Worker
   cd worker && source .venv/bin/activate && python worker.py
   ```

5. **Access the application**
   - Frontend: http://localhost:5000
   - Backend API: http://localhost:3001
   - Health check: http://localhost:3001/health

## 📦 Building for Production

```bash
# Build frontend
cd frontend
npm run build

# Build backend
cd backend
npm run build
```

## 🧪 Running Tests

```bash
# Frontend tests
cd frontend
npm test

# Backend tests
cd backend
npm test
```

## ☁️ Cloudflare Deployment

This project is configured to deploy to Cloudflare infrastructure:
- **Frontend**: Cloudflare Pages
- **Backend API**: Cloudflare Workers

### Migration from Deno

**Note**: This project was initially designed for Deno Deploy but has been migrated to Cloudflare for better global performance, edge computing capabilities, and integrated CDN. The Cloudflare Workers runtime provides similar edge execution with enhanced features for video processing and storage.

### Required GitHub Secrets

Configure these secrets in your GitHub repository (Settings → Secrets and variables → Actions):

| Secret Name | Description | Where to Find |
|------------|-------------|---------------|
| `CLOUDFLARE_API_TOKEN` | Cloudflare API token with appropriate permissions | https://dash.cloudflare.com/profile/api-tokens |
| `CLOUDFLARE_ACCOUNT_ID` | Your Cloudflare account ID | https://dash.cloudflare.com/ (right sidebar) |
| `CF_PAGES_PROJECT` | Name of your Cloudflare Pages project | Choose any name (e.g., "ai-video-factory") |
| `CLOUDFLARE_ZONE_ID` | (Optional) Zone ID for custom domain | https://dash.cloudflare.com/ → Select domain |

### Setting Up Cloudflare Deployment

1. **Create Cloudflare Pages Project**
   - Go to https://dash.cloudflare.com/
   - Navigate to Workers & Pages → Create application → Pages
   - Connect to your GitHub repository
   - Or create via API using the `CF_PAGES_PROJECT` secret

2. **Configure Wrangler for Workers**
   ```bash
   cd infra/cloudflare/worker
   # Update wrangler.toml with your account_id
   npx wrangler login
   npx wrangler deploy
   ```

3. **Trigger Deployment**
   - Push to `main` branch to trigger automatic deployment
   - Or manually trigger via GitHub Actions

### Manual Deployment

```bash
# Deploy frontend to Cloudflare Pages
cd frontend
npm run build
npx wrangler pages publish dist --project-name=ai-video-factory

# Deploy backend to Cloudflare Workers
cd infra/cloudflare/worker
npx wrangler deploy
```

## 📡 API Documentation

### Create Video Job

**POST** `/api/create-video`

Create a new video generation job.

**Request Body:**
```json
{
  "prompt": "A serene mountain landscape at sunset",
  "voice": "neutral",
  "style": "cinematic",
  "length": 30
}
```

**Response:** `202 Accepted`
```json
{
  "jobId": "550e8400-e29b-41d4-a716-446655440000",
  "status": "pending",
  "estimatedCompletionMs": 60000,
  "message": "Video generation job created successfully"
}
```

**Example:**
```bash
curl -X POST http://localhost:3001/api/create-video \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "A beautiful sunset over the ocean",
    "voice": "female",
    "style": "realistic",
    "length": 15
  }'
```

### Get Job Status

**GET** `/api/status/:jobId`

Retrieve the current status of a video generation job.

**Response:** `200 OK`
```json
{
  "jobId": "550e8400-e29b-41d4-a716-446655440000",
  "status": "completed",
  "createdAt": 1704067200000,
  "updatedAt": 1704067260000,
  "outputUrl": "/api/videos/550e8400-e29b-41d4-a716-446655440000.mp4",
  "progress": 100
}
```

**Status Values:**
- `pending`: Job is in queue
- `processing`: Video is being generated
- `completed`: Video is ready
- `failed`: Generation failed

**Example:**
```bash
curl http://localhost:3001/api/status/550e8400-e29b-41d4-a716-446655440000
```

### Health Check

**GET** `/health`

Check API health status.

**Response:** `200 OK`
```json
{
  "status": "healthy",
  "timestamp": "2024-01-01T00:00:00.000Z",
  "service": "ai-video-factory-backend"
}
```

## 🔧 Configuration

### Environment Variables

#### Frontend
- `VITE_API_URL`: Backend API URL (default: http://localhost:3001)

#### Backend
- `BACKEND_PORT`: Server port (default: 3001)
- `NODE_ENV`: Environment (development/production)
- `CORS_ORIGIN`: Allowed CORS origin (default: http://localhost:5000)
- `STORAGE_PATH`: Local storage path for uploads

#### Worker
- `BACKEND_URL`: Backend API URL (default: http://localhost:3001)
- `POLL_INTERVAL`: Polling interval in seconds (default: 5)

## 🤖 AI Integration

The worker currently uses simulated AI generation. To integrate real AI services:

### Video Generation
- **Runway ML**: Text-to-video generation
- **Stable Diffusion Video**: Open-source video generation
- **Custom models**: Fine-tuned models via Hugging Face

### Voice Synthesis
- **ElevenLabs**: High-quality AI voices
- **Google Cloud TTS**: Multilingual text-to-speech
- **Azure Speech**: Enterprise-grade voice synthesis

### Video Processing
- **FFmpeg**: Video compositing and effects
- **Cloudflare Stream**: Video encoding and delivery

See `worker/utils/ai_helper.py` for integration examples and TODOs.

## 🔐 Security

- Never commit `.env` files or secrets
- Use GitHub Secrets for CI/CD credentials
- API tokens should have minimum required permissions
- Implement rate limiting in production
- Validate all user inputs on backend

## 📊 Monitoring & Logging

- Backend logs to stdout (capture with your logging service)
- Worker logs processing steps and errors
- Use `./logs/` directory for local development logs
- Integrate with Cloudflare Analytics for production metrics

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Built with React, Express, and Python
- Deployed on Cloudflare's edge network
- Designed for scalable AI video generation

## 📞 Support

For issues, questions, or contributions:
- Open an issue on GitHub
- Check existing documentation
- Review API examples above

---

**Made with ❤️ by the AI Video Factory team**
