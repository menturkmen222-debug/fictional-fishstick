import { describe, it, expect } from 'vitest';
import { formatDuration, formatDate, US_OPTIMAL_HOURS } from '../frontend/src/utils/time';

describe('Frontend Utils Tests', () => {
  describe('formatDuration', () => {
    it('should format seconds correctly', () => {
      expect(formatDuration(5000)).toBe('5s');
      expect(formatDuration(30000)).toBe('30s');
    });

    it('should format minutes correctly', () => {
      expect(formatDuration(60000)).toBe('1m 0s');
      expect(formatDuration(90000)).toBe('1m 30s');
      expect(formatDuration(300000)).toBe('5m 0s');
    });

    it('should format hours correctly', () => {
      expect(formatDuration(3600000)).toBe('1h 0m');
      expect(formatDuration(5400000)).toBe('1h 30m');
    });
  });

  describe('formatDate', () => {
    it('should format timestamp to readable date', () => {
      const timestamp = 1704067200000; // Jan 1, 2024 00:00:00 UTC
      const formatted = formatDate(timestamp);
      expect(formatted).toContain('2024');
    });
  });

  describe('US_OPTIMAL_HOURS', () => {
    it('should export US_OPTIMAL_HOURS constant', () => {
      expect(US_OPTIMAL_HOURS).toBeDefined();
      expect(Array.isArray(US_OPTIMAL_HOURS)).toBe(true);
      expect(US_OPTIMAL_HOURS).toEqual([6, 10, 14, 18, 22]);
    });
  });
});
