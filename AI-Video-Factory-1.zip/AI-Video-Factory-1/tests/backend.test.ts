import request from 'supertest';
import app from '../backend/src/index';

describe('Backend API Tests', () => {
  describe('POST /api/create-video', () => {
    it('should return 202 and create a video job', async () => {
      const response = await request(app)
        .post('/api/create-video')
        .send({
          prompt: 'A beautiful sunset over mountains',
          voice: 'neutral',
          style: 'cinematic',
          length: 30
        });

      expect(response.status).toBe(202);
      expect(response.body).toHaveProperty('jobId');
      expect(response.body).toHaveProperty('status', 'pending');
      expect(response.body).toHaveProperty('estimatedCompletionMs');
    });

    it('should return 400 for missing prompt', async () => {
      const response = await request(app)
        .post('/api/create-video')
        .send({
          voice: 'neutral',
          style: 'cinematic',
          length: 30
        });

      expect(response.status).toBe(400);
      expect(response.body).toHaveProperty('error');
    });

    it('should return 400 for invalid length', async () => {
      const response = await request(app)
        .post('/api/create-video')
        .send({
          prompt: 'Test',
          voice: 'neutral',
          style: 'cinematic',
          length: 500  // Too long
        });

      expect(response.status).toBe(400);
      expect(response.body).toHaveProperty('error');
    });
  });

  describe('GET /api/status/:jobId', () => {
    it('should return 200 and job status for valid job', async () => {
      // First create a job
      const createResponse = await request(app)
        .post('/api/create-video')
        .send({
          prompt: 'Test video',
          voice: 'neutral',
          style: 'cinematic',
          length: 10
        });

      const jobId = createResponse.body.jobId;

      // Then check status
      const statusResponse = await request(app)
        .get(`/api/status/${jobId}`);

      expect(statusResponse.status).toBe(200);
      expect(statusResponse.body).toHaveProperty('jobId', jobId);
      expect(statusResponse.body).toHaveProperty('status');
      expect(statusResponse.body).toHaveProperty('progress');
    });

    it('should return 404 for non-existent job', async () => {
      const response = await request(app)
        .get('/api/status/non-existent-job-id');

      expect(response.status).toBe(404);
      expect(response.body).toHaveProperty('error');
    });
  });

  describe('GET /health', () => {
    it('should return 200 and health status', async () => {
      const response = await request(app).get('/health');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('status', 'healthy');
      expect(response.body).toHaveProperty('service', 'ai-video-factory-backend');
    });
  });
});
