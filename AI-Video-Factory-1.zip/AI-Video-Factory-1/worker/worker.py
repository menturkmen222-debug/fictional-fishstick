#!/usr/bin/env python3
"""
AI Video Factory Worker

This worker polls the backend API for pending video generation jobs,
processes them using AI helpers, and uploads the results back to the backend.

TODO: Integrate with real AI services:
- Video generation: Runway ML, Stable Diffusion Video, or custom models
- Voice synthesis: ElevenLabs, Google TTS, or Azure Speech
- Video editing: FFmpeg for compositing and effects
"""

import os
import sys
import time
import requests
from typing import Optional, Dict, Any
from utils.ai_helper import generate_video

# Configuration
BACKEND_URL = os.getenv('BACKEND_URL', 'http://localhost:3001')
POLL_INTERVAL = int(os.getenv('POLL_INTERVAL', '5'))  # seconds
MAX_RETRIES = 3

def fetch_pending_jobs() -> list[Dict[str, Any]]:
    """
    Fetch pending jobs from backend queue.
    
    Note: This is a simplified implementation. In production, you would:
    - Use a proper job queue (Redis, RabbitMQ, AWS SQS)
    - Implement job locking to prevent race conditions
    - Add authentication and authorization
    """
    try:
        response = requests.get(f'{BACKEND_URL}/api/jobs/pending', timeout=10)
        if response.status_code == 200:
            return response.json().get('jobs', [])
        else:
            print(f"[Worker] Failed to fetch jobs: HTTP {response.status_code}")
            return []
    except requests.exceptions.RequestException as e:
        print(f"[Worker] Error fetching jobs: {e}")
        return []

def update_job_status(job_id: str, status: str, output_url: Optional[str] = None, error: Optional[str] = None) -> bool:
    """Update job status in backend."""
    try:
        payload = {
            'status': status,
            'outputUrl': output_url,
            'error': error
        }
        response = requests.patch(
            f'{BACKEND_URL}/api/jobs/{job_id}/status',
            json=payload,
            timeout=10
        )
        return response.status_code == 200
    except requests.exceptions.RequestException as e:
        print(f"[Worker] Error updating job status: {e}")
        return False

def upload_video(job_id: str, video_path: str) -> Optional[str]:
    """
    Upload generated video to backend storage.
    
    In production, this might upload to:
    - Cloud storage (S3, GCS, Azure Blob, Cloudflare R2)
    - CDN for global distribution
    - Database with proper metadata
    """
    try:
        with open(video_path, 'rb') as video_file:
            files = {'video': (f'{job_id}.mp4', video_file, 'video/mp4')}
            response = requests.post(
                f'{BACKEND_URL}/api/upload/{job_id}',
                files=files,
                timeout=60
            )
            
            if response.status_code == 200:
                data = response.json()
                return data.get('url')
            else:
                print(f"[Worker] Upload failed: HTTP {response.status_code}")
                return None
    except requests.exceptions.RequestException as e:
        print(f"[Worker] Error uploading video: {e}")
        return None
    except IOError as e:
        print(f"[Worker] Error reading video file: {e}")
        return None

def process_job(job: Dict[str, Any]) -> bool:
    """Process a single video generation job."""
    job_id = job['id']
    prompt = job['prompt']
    voice = job['voice']
    style = job['style']
    length = job['length']
    
    print(f"\n[Worker] Processing job {job_id}")
    print(f"  Prompt: {prompt[:50]}...")
    
    try:
        # Update status to processing
        update_job_status(job_id, 'processing')
        
        # Generate video using AI helper
        video_path = generate_video(prompt, length, voice, style)
        
        if not os.path.exists(video_path):
            raise Exception(f"Video file not generated: {video_path}")
        
        # Upload video to backend
        output_url = upload_video(job_id, video_path)
        
        if not output_url:
            raise Exception("Failed to upload video")
        
        # Update job as completed
        update_job_status(job_id, 'completed', output_url=output_url)
        
        print(f"[Worker] Job {job_id} completed successfully")
        
        # Clean up local file
        try:
            os.remove(video_path)
        except OSError:
            pass
        
        return True
        
    except Exception as e:
        error_msg = str(e)
        print(f"[Worker] Job {job_id} failed: {error_msg}")
        update_job_status(job_id, 'failed', error=error_msg)
        return False

def main():
    """Main worker loop."""
    print("╔════════════════════════════════════════════════╗")
    print("║   AI Video Factory Worker                      ║")
    print("║   Waiting for video generation jobs...         ║")
    print(f"║   Backend: {BACKEND_URL:31} ║")
    print(f"║   Poll interval: {POLL_INTERVAL}s{' ' * 30} ║")
    print("╚════════════════════════════════════════════════╝\n")
    
    while True:
        try:
            # Fetch pending jobs
            jobs = fetch_pending_jobs()
            
            if jobs:
                print(f"[Worker] Found {len(jobs)} pending job(s)")
                for job in jobs:
                    process_job(job)
            else:
                print(f"[Worker] No pending jobs. Waiting {POLL_INTERVAL}s...")
            
            # Wait before next poll
            time.sleep(POLL_INTERVAL)
            
        except KeyboardInterrupt:
            print("\n[Worker] Shutting down gracefully...")
            sys.exit(0)
        except Exception as e:
            print(f"[Worker] Unexpected error: {e}")
            time.sleep(POLL_INTERVAL)

if __name__ == '__main__':
    main()
