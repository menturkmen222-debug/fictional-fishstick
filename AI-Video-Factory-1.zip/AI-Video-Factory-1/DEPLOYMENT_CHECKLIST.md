# 🚀 AI Video Factory - Deployment Checklist

Complete this checklist to successfully deploy your AI Video Factory project.

## ✅ Pre-Deployment Checklist

### 1. Local Development Setup
- [ ] Run `./scripts/setup_env.sh` to install all dependencies
- [ ] Create `.env` files in `frontend/` and `backend/` directories
- [ ] Test frontend locally: `cd frontend && npm run dev`
- [ ] Test backend locally: `cd backend && npm run dev`
- [ ] Test Python worker: `cd worker && python worker.py`
- [ ] Verify all three services work together

### 2. Code Quality
- [ ] Run TypeScript checks: `cd backend && npm run build`
- [ ] Run frontend build: `cd frontend && npm run build`
- [ ] Fix any TypeScript errors
- [ ] Run tests (optional): `npm test` in backend/frontend

### 3. GitHub Repository Setup
- [ ] Follow instructions in `GIT_SETUP_INSTRUCTIONS.md`
- [ ] Create GitHub repository: `ai-video-factory`
- [ ] Push code to `main` branch
- [ ] Create and push `dev` branch
- [ ] Create initial Pull Request: `dev` → `main`

### 4. Cloudflare Account Setup
- [ ] Sign up for Cloudflare account (if not already)
- [ ] Verify email and complete account setup
- [ ] Note your Account ID from dashboard

### 5. GitHub Secrets Configuration
Add these secrets in GitHub Settings → Secrets and variables → Actions:

- [ ] `CLOUDFLARE_API_TOKEN`
  - Create at: https://dash.cloudflare.com/profile/api-tokens
  - Permissions: "Edit Cloudflare Workers" + "Edit Cloudflare Pages"
  
- [ ] `CLOUDFLARE_ACCOUNT_ID`
  - Found at: https://dash.cloudflare.com/ (right sidebar)
  
- [ ] `CF_PAGES_PROJECT`
  - Choose name: `ai-video-factory` (or your preference)
  
- [ ] `CLOUDFLARE_ZONE_ID` (Optional, for custom domains)
  - Found at: https://dash.cloudflare.com/ → Select domain

### 6. Cloudflare Pages Setup
- [ ] Go to https://dash.cloudflare.com/
- [ ] Navigate to Workers & Pages → Create application → Pages
- [ ] Connect to your GitHub repository
- [ ] Configure build settings:
  - Build command: `cd frontend && npm run build`
  - Build output directory: `frontend/dist`
  - Root directory: `/`
- [ ] Add environment variable: `VITE_API_URL` = `https://api.your-domain.workers.dev`

### 7. Cloudflare Workers Setup (Backend API)
- [ ] Install Wrangler CLI: `npm install -g wrangler`
- [ ] Login: `wrangler login`
- [ ] Update `infra/cloudflare/worker/wrangler.toml`:
  - Replace `YOUR_CLOUDFLARE_ACCOUNT_ID` with your actual account ID
  - Update `route` pattern if using custom domain
- [ ] Deploy manually first: `cd infra/cloudflare/worker && wrangler deploy`

### 8. Environment Variables
Update production environment variables:

**Frontend (.env.production or Cloudflare Pages environment variables):**
```env
VITE_API_URL=https://your-worker-name.your-account.workers.dev
```

**Backend (Cloudflare Workers environment variables):**
```env
NODE_ENV=production
CORS_ORIGIN=https://your-pages-site.pages.dev
```

### 9. CI/CD Pipeline
- [ ] Verify `.github/workflows/ci.yml` runs on PR to dev
- [ ] Verify `.github/workflows/deploy-cloudflare.yml` configured
- [ ] Test CI by creating a PR
- [ ] Test deployment by merging to main

### 10. Worker Deployment (Python)
The Python worker needs separate deployment:

**Option A: Deploy to Cloud VM**
- [ ] Deploy to AWS EC2, Google Cloud Compute, or Azure VM
- [ ] Install Python 3.9+
- [ ] Clone repository
- [ ] Run: `cd worker && pip install -r requirements.txt`
- [ ] Configure `BACKEND_URL` environment variable
- [ ] Run as background service: `nohup python worker.py &`

**Option B: Deploy to Container Service**
- [ ] Create Dockerfile for worker
- [ ] Push to Docker Hub or container registry
- [ ] Deploy to AWS ECS, Google Cloud Run, or Azure Container Instances

**Option C: Keep Running Locally (Development)**
- [ ] Run worker on your local machine
- [ ] Ensure backend API is publicly accessible
- [ ] Configure worker with production API URL

## 🧪 Testing Deployment

### 1. Test Frontend
- [ ] Visit your Cloudflare Pages URL
- [ ] Verify UI loads correctly
- [ ] Check browser console for errors

### 2. Test Backend API
- [ ] Test health endpoint: `curl https://your-worker.workers.dev/health`
- [ ] Test create video: 
```bash
curl -X POST https://your-worker.workers.dev/api/create-video \
  -H "Content-Type: application/json" \
  -d '{"prompt":"test","voice":"neutral","style":"cinematic","length":10}'
```
- [ ] Test status endpoint with returned jobId

### 3. Test Full Integration
- [ ] Submit video request through frontend
- [ ] Verify job creation
- [ ] Check job status updates
- [ ] Verify worker processes jobs (check worker logs)
- [ ] Confirm video generation completes

## 🔧 Post-Deployment Configuration

### 1. Custom Domain (Optional)
- [ ] Add domain to Cloudflare
- [ ] Configure DNS records
- [ ] Update environment variables with custom domain
- [ ] Update CORS_ORIGIN in backend

### 2. Monitoring
- [ ] Set up Cloudflare Analytics
- [ ] Configure error notifications
- [ ] Monitor worker execution logs
- [ ] Set up uptime monitoring

### 3. Storage Configuration
For production, replace in-memory storage:
- [ ] Set up Cloudflare R2 for video storage
- [ ] Configure KV namespace for job queue
- [ ] Update backend storage service
- [ ] Migrate from local file storage

### 4. AI Service Integration
Replace simulated AI generation:
- [ ] Sign up for AI services (Runway ML, ElevenLabs, etc.)
- [ ] Get API keys
- [ ] Update `worker/utils/ai_helper.py`
- [ ] Test real video generation
- [ ] Configure rate limits and quotas

## 🐛 Troubleshooting

### Deployment fails
- Verify all GitHub secrets are set correctly
- Check Cloudflare account has sufficient permissions
- Review GitHub Actions logs for errors

### Frontend can't reach backend
- Verify VITE_API_URL is correct
- Check CORS configuration in backend
- Verify backend is deployed and accessible

### Worker not processing jobs
- Check worker is running
- Verify BACKEND_URL points to production API
- Check worker logs for errors
- Ensure API endpoints are accessible from worker

### Build fails
- Clear caches: `rm -rf node_modules && npm install`
- Verify TypeScript compiles: `npm run build`
- Check for missing dependencies

## 📊 Success Criteria

Deployment is successful when:
- ✅ Frontend loads at Cloudflare Pages URL
- ✅ Backend API responds to health check
- ✅ Video creation request returns job ID
- ✅ Worker processes jobs and generates videos
- ✅ Frontend displays video generation status
- ✅ Generated videos are accessible
- ✅ CI/CD pipeline runs on commits
- ✅ All automated tests pass

## 📚 Additional Resources

- [Cloudflare Pages Docs](https://developers.cloudflare.com/pages/)
- [Cloudflare Workers Docs](https://developers.cloudflare.com/workers/)
- [Cloudflare R2 Storage](https://developers.cloudflare.com/r2/)
- [GitHub Actions Docs](https://docs.github.com/en/actions)

## 🎉 Next Steps After Deployment

1. Integrate real AI services
2. Add user authentication
3. Implement rate limiting
4. Set up analytics and monitoring
5. Add payment processing (if monetizing)
6. Optimize video processing pipeline
7. Add more video styles and options
8. Implement video templates
9. Add social sharing features
10. Create marketing site

---

**Need Help?** Check the README.md for detailed documentation or review the GIT_SETUP_INSTRUCTIONS.md for repository setup.
