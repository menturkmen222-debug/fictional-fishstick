#!/bin/bash

# AI Video Factory - Local Development Deployment Script
# Starts all services concurrently for local development

set -e

echo "╔════════════════════════════════════════════════╗"
echo "║   AI Video Factory - Local Deployment          ║"
echo "╚════════════════════════════════════════════════╝"
echo ""

# Check if dependencies are installed
if [ ! -d "backend/node_modules" ]; then
    echo "Backend dependencies not found. Run ./scripts/setup_env.sh first."
    exit 1
fi

if [ ! -d "frontend/node_modules" ]; then
    echo "Frontend dependencies not found. Run ./scripts/setup_env.sh first."
    exit 1
fi

if [ ! -d "worker/.venv" ]; then
    echo "Python worker environment not found. Run ./scripts/setup_env.sh first."
    exit 1
fi

# Create log directory
mkdir -p logs

# Cleanup function
cleanup() {
    echo ""
    echo "Shutting down services..."
    kill $(jobs -p) 2>/dev/null || true
    exit 0
}

trap cleanup SIGINT SIGTERM

echo "Starting services..."
echo ""

# Start backend API
echo "🚀 Starting Backend API on port 3001..."
cd backend && npm run dev > ../logs/backend.log 2>&1 &
BACKEND_PID=$!
cd ..

# Start frontend
echo "🚀 Starting Frontend on port 5000..."
cd frontend && npm run dev > ../logs/frontend.log 2>&1 &
FRONTEND_PID=$!
cd ..

# Start Python worker
echo "🚀 Starting Python Worker..."
cd worker && source .venv/bin/activate && python worker.py > ../logs/worker.log 2>&1 &
WORKER_PID=$!
cd ..

echo ""
echo "╔════════════════════════════════════════════════╗"
echo "║   All services started!                        ║"
echo "╚════════════════════════════════════════════════╝"
echo ""
echo "  Frontend:  http://localhost:5000"
echo "  Backend:   http://localhost:3001"
echo "  Worker:    Running in background"
echo ""
echo "  Logs are being written to ./logs/"
echo ""
echo "  Press Ctrl+C to stop all services"
echo ""

# Wait for processes
wait $BACKEND_PID $FRONTEND_PID $WORKER_PID
