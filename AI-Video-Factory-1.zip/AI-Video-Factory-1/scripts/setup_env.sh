#!/bin/bash

# AI Video Factory - Environment Setup Script
# This script helps set up the development environment

set -e

echo "╔════════════════════════════════════════════════╗"
echo "║   AI Video Factory - Environment Setup         ║"
echo "╚════════════════════════════════════════════════╝"
echo ""

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo -e "${YELLOW}Warning: Node.js is not installed${NC}"
    echo "Please install Node.js 20+ from https://nodejs.org/"
    exit 1
fi

echo -e "${GREEN}✓${NC} Node.js $(node --version) detected"

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo -e "${YELLOW}Warning: Python 3 is not installed${NC}"
    echo "Please install Python 3.9+ from https://python.org/"
    exit 1
fi

echo -e "${GREEN}✓${NC} Python $(python3 --version) detected"

# Setup backend
echo ""
echo "Setting up backend..."
cd backend
cp .env.example .env 2>/dev/null || echo "No .env.example found in backend"
npm install
cd ..
echo -e "${GREEN}✓${NC} Backend dependencies installed"

# Setup frontend
echo ""
echo "Setting up frontend..."
cd frontend
cp .env.example .env 2>/dev/null || echo "No .env.example found in frontend"
npm install
cd ..
echo -e "${GREEN}✓${NC} Frontend dependencies installed"

# Setup Python worker
echo ""
echo "Setting up Python worker..."
cd worker
python3 -m venv .venv
source .venv/bin/activate || . .venv/Scripts/activate
pip install -r requirements.txt
deactivate
cd ..
echo -e "${GREEN}✓${NC} Python worker dependencies installed"

# Create necessary directories
mkdir -p backend/uploads
echo -e "${GREEN}✓${NC} Created uploads directory"

echo ""
echo "╔════════════════════════════════════════════════╗"
echo "║   Setup Complete!                              ║"
echo "╚════════════════════════════════════════════════╝"
echo ""
echo "Next steps:"
echo "  1. Update .env files in frontend/ and backend/ with your configuration"
echo "  2. Run 'npm run dev' in backend/ to start the API server"
echo "  3. Run 'npm run dev' in frontend/ to start the web app"
echo "  4. Run 'python3 worker.py' in worker/ to start the worker"
echo ""
echo "Or use the deploy_local.sh script to start all services at once."
