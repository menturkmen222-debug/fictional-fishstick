import { v4 as uuidv4 } from 'uuid';
import { getCurrentTimestamp } from '../utils/time.js';

export type JobStatus = 'pending' | 'processing' | 'completed' | 'failed';

export interface VideoJob {
  id: string;
  prompt: string;
  voice: string;
  style: string;
  length: number;
  status: JobStatus;
  createdAt: number;
  updatedAt: number;
  outputUrl?: string;
  error?: string;
}

export interface CreateJobParams {
  prompt: string;
  voice: string;
  style: string;
  length: number;
}

class JobQueue {
  private jobs: Map<string, VideoJob> = new Map();

  createJob(params: CreateJobParams): VideoJob {
    const jobId = uuidv4();
    const now = getCurrentTimestamp();
    
    const job: VideoJob = {
      id: jobId,
      prompt: params.prompt,
      voice: params.voice,
      style: params.style,
      length: params.length,
      status: 'pending',
      createdAt: now,
      updatedAt: now
    };

    this.jobs.set(jobId, job);
    console.log(`[JobQueue] Created job ${jobId} - ${params.prompt.substring(0, 50)}...`);
    
    return job;
  }

  getJob(jobId: string): VideoJob | undefined {
    return this.jobs.get(jobId);
  }

  updateJobStatus(jobId: string, status: JobStatus, outputUrl?: string, error?: string): boolean {
    const job = this.jobs.get(jobId);
    if (!job) {
      return false;
    }

    job.status = status;
    job.updatedAt = getCurrentTimestamp();
    if (outputUrl) {
      job.outputUrl = outputUrl;
    }
    if (error) {
      job.error = error;
    }

    this.jobs.set(jobId, job);
    console.log(`[JobQueue] Updated job ${jobId} to status: ${status}`);
    
    return true;
  }

  getPendingJobs(): VideoJob[] {
    return Array.from(this.jobs.values()).filter(job => job.status === 'pending');
  }

  getAllJobs(): VideoJob[] {
    return Array.from(this.jobs.values());
  }

  deleteJob(jobId: string): boolean {
    return this.jobs.delete(jobId);
  }
}

// Singleton instance
export const jobQueue = new JobQueue();
