import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export interface StorageService {
  saveVideo(jobId: string, data: Buffer): Promise<string>;
  getVideoUrl(jobId: string): string;
  fileExists(jobId: string): boolean;
}

class LocalStorage implements StorageService {
  private uploadsDir: string;

  constructor() {
    this.uploadsDir = process.env.STORAGE_PATH || path.join(__dirname, '../../uploads');
    this.ensureUploadsDirExists();
  }

  private ensureUploadsDirExists(): void {
    if (!fs.existsSync(this.uploadsDir)) {
      fs.mkdirSync(this.uploadsDir, { recursive: true });
      console.log(`[Storage] Created uploads directory: ${this.uploadsDir}`);
    }
  }

  async saveVideo(jobId: string, data: Buffer): Promise<string> {
    const filename = `${jobId}.mp4`;
    const filepath = path.join(this.uploadsDir, filename);
    
    await fs.promises.writeFile(filepath, data);
    console.log(`[Storage] Saved video for job ${jobId} (${data.length} bytes)`);
    
    return filename;
  }

  getVideoUrl(jobId: string): string {
    // In production, this would be a CDN URL or cloud storage URL
    // For now, return a relative path that the API will serve
    return `/api/videos/${jobId}.mp4`;
  }

  fileExists(jobId: string): boolean {
    const filename = `${jobId}.mp4`;
    const filepath = path.join(this.uploadsDir, filename);
    return fs.existsSync(filepath);
  }
}

// Singleton instance
// TODO: Replace with cloud storage (S3, Cloudflare R2, etc.) in production
export const storage = new LocalStorage();
