import express from 'express';
import cors from 'cors';
import createVideoRouter from './routes/createVideo.js';
import statusRouter from './routes/status.js';
import { storage } from './services/storage.js';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.BACKEND_PORT || 3001;
const CORS_ORIGIN = process.env.CORS_ORIGIN || 'http://localhost:5000';

// Middleware
app.use(cors({
  origin: CORS_ORIGIN,
  credentials: true
}));
app.use(express.json());

// Request logging
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// API Routes
app.use('/api', createVideoRouter);
app.use('/api', statusRouter);

// Serve video files
app.get('/api/videos/:filename', (req, res) => {
  const filename = req.params.filename;
  const uploadsDir = process.env.STORAGE_PATH || path.join(__dirname, '../uploads');
  const filepath = path.join(uploadsDir, filename);

  if (!fs.existsSync(filepath)) {
    res.status(404).json({ error: 'Video not found' });
    return;
  }

  res.sendFile(filepath);
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString(),
    service: 'ai-video-factory-backend'
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Not found' });
});

// Error handler
app.use((err: Error, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('[Error]', err);
  res.status(500).json({ error: 'Internal server error' });
});

// Start server
app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════════════╗
║   AI Video Factory Backend API                 ║
║   Server running on port ${PORT}                  ║
║   CORS enabled for: ${CORS_ORIGIN}
║   Environment: ${process.env.NODE_ENV || 'development'}                ║
╚════════════════════════════════════════════════╝
  `);
});

export default app;
