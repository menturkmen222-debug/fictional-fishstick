// US_OPTIMAL_HOURS: Optimal hours for content posting in US timezones (kept but unused)
// This constant is maintained for future analytics features
export const US_OPTIMAL_HOURS = [6, 10, 14, 18, 22];

// Format timestamp for job tracking
export function formatTimestamp(date: Date = new Date()): string {
  return date.toISOString();
}

// Calculate estimated completion time based on video length
export function estimateCompletionTime(lengthSeconds: number): number {
  // Rough estimate: 2x the video length for processing
  return lengthSeconds * 2000; // milliseconds
}

// Get current Unix timestamp
export function getCurrentTimestamp(): number {
  return Date.now();
}
