import { Router, Request, Response } from 'express';
import { jobQueue } from '../services/jobQueue.js';
import { estimateCompletionTime } from '../utils/time.js';

const router = Router();

interface CreateVideoRequest {
  prompt: string;
  voice: string;
  style: string;
  length: number;
}

router.post('/create-video', (req: Request, res: Response) => {
  try {
    const { prompt, voice, style, length } = req.body as CreateVideoRequest;

    // Validation
    if (!prompt || typeof prompt !== 'string' || prompt.trim().length === 0) {
      res.status(400).json({ error: 'Prompt is required and must be a non-empty string' });
      return;
    }

    if (!voice || typeof voice !== 'string') {
      res.status(400).json({ error: 'Voice is required' });
      return;
    }

    if (!style || typeof style !== 'string') {
      res.status(400).json({ error: 'Style is required' });
      return;
    }

    if (!length || typeof length !== 'number' || length <= 0 || length > 300) {
      res.status(400).json({ error: 'Length must be a number between 1 and 300 seconds' });
      return;
    }

    // Create job
    const job = jobQueue.createJob({
      prompt,
      voice,
      style,
      length
    });

    const estimatedMs = estimateCompletionTime(length);

    // Return 202 Accepted with job details
    res.status(202).json({
      jobId: job.id,
      status: job.status,
      estimatedCompletionMs: estimatedMs,
      message: 'Video generation job created successfully'
    });
  } catch (error) {
    console.error('[CreateVideo] Error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
