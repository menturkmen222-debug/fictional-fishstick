import { Router, Request, Response } from 'express';
import { jobQueue } from '../services/jobQueue.js';

const router = Router();

router.get('/status/:jobId', (req: Request, res: Response) => {
  try {
    const { jobId } = req.params;

    if (!jobId) {
      res.status(400).json({ error: 'Job ID is required' });
      return;
    }

    const job = jobQueue.getJob(jobId);

    if (!job) {
      res.status(404).json({ error: 'Job not found' });
      return;
    }

    res.status(200).json({
      jobId: job.id,
      status: job.status,
      createdAt: job.createdAt,
      updatedAt: job.updatedAt,
      outputUrl: job.outputUrl,
      error: job.error,
      progress: job.status === 'completed' ? 100 : job.status === 'processing' ? 50 : 0
    });
  } catch (error) {
    console.error('[Status] Error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
